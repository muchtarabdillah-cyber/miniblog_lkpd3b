MINI BLOG FLASK — VERSI LENGKAP BAB 1–12

PENTING SEBELUM MEMAKAI
1. Cadangkan folder proyek lama terlebih dahulu.
2. Jangan menimpa database lama tanpa cadangan. Struktur database versi ini memakai relasi User–Post.
3. Ekstrak berkas proyek ini ke folder baru, misalnya:
   C:\Users\muchtar1922\Documents\miniblog-final
4. Jangan salin folder venv atau database lama ke folder baru.

CARA MENJALANKAN (PowerShell)
cd C:\Users\muchtar1922\Documents\miniblog-final
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m flask --app run.py init-db
python run.py

Buka http://127.0.0.1:8080

AKUN CONTOH
Username: admin
Password: admin12345
Akun contoh dibuat oleh perintah init-db untuk pembelajaran lokal. Setelah masuk, artikel contoh dimiliki akun admin.

FITUR YANG DISESUAIKAN DENGAN MATERI BAB 1–12
- Home, About, daftar artikel, detail artikel dan navbar bersama Jinja2
- Routing dinamis /siswa/Nama, /nilai/80, /kali/2/3
- CSS dari app/static/style.css
- Form tambah/edit dengan validasi, flash message, dan redirect
- SQLite dan Flask-SQLAlchemy
- CRUD artikel
- Relasi User–Post; hanya pemilik artikel dapat mengedit atau menghapus
- Registrasi, login, logout, password di-hash
- Halaman error 403, 404, 500
- Konfigurasi di config.py; SECRET_KEY bisa diatur lewat environment variable
- API GET daftar/detail, POST buat artikel, pencarian, jumlah artikel, dan DELETE milik sendiri
- tes_api.py untuk uji dasar

DATABASE
Aplikasi membuat tabel saat dijalankan, tetapi untuk mengisi tiga artikel contoh pertama kali jalankan:
python -m flask --app run.py init-db

Jika ingin menjalankan pengujian dari database kosong, buat cadangan dulu lalu hapus instance/blog.db di folder proyek baru dan jalankan lagi perintah init-db.
