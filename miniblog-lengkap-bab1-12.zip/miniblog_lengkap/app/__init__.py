import os
from flask import Flask, render_template
from config import Config
from app.extensions import db, login_manager


def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)
    os.makedirs(app.instance_path, exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    from app import models  # noqa: F401
    from app.blog import blog_bp
    from app.auth import auth_bp
    from app.api import api_bp

    app.register_blueprint(blog_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(api_bp)

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        # Endpoint API menangani 404 sendiri agar respons tetap JSON.
        if app.request_class:
            from flask import request, jsonify
            if request.path.startswith("/api/"):
                return jsonify({"error": "Data atau endpoint tidak ditemukan"}), 404
        return render_template("404.html"), 404

    @app.errorhandler(500)
    def server_error(error):
        db.session.rollback()
        return render_template("500.html"), 500

    with app.app_context():
        db.create_all()

    return app
