from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import Post

blog_bp = Blueprint("blog", __name__)
nama_blog = "Mini Blog"


@blog_bp.route("/")
def home():
    posts = Post.query.order_by(Post.tanggal.desc()).limit(5).all()
    return render_template("index.html", nama_blog=nama_blog, posts=posts)


@blog_bp.route("/siswa/<string:nama>")
def siswa(nama):
    return f"Halo, {nama}!"


@blog_bp.route("/nilai/<int:angka>")
def nilai(angka):
    return "Lulus" if angka >= 75 else "Belum lulus"


@blog_bp.route("/kali/<int:a>/<int:b>")
def kali(a, b):
    return f"Hasil perkalian {a} x {b} = {a * b}"


@blog_bp.route("/about")
def about():
    return render_template("about.html", nama_blog=nama_blog)


@blog_bp.route("/posts")
def posts():
    semua_post = Post.query.order_by(Post.tanggal.desc()).all()
    return render_template("posts.html", nama_blog=nama_blog, posts=semua_post,
                           total=Post.query.count())


@blog_bp.route("/post/<int:post_id>")
def post_detail(post_id):
    post = db.get_or_404(Post, post_id)
    return render_template("detail.html", nama_blog=nama_blog, post=post)


@blog_bp.route("/tambah", methods=["GET", "POST"])
@login_required
def create_post():
    judul = ""
    isi = ""
    if request.method == "POST":
        judul = request.form.get("judul", "").strip()
        isi = request.form.get("isi", "").strip()
        if not judul or not isi:
            flash("Judul dan isi wajib diisi.", "error")
        elif len(judul) < 5:
            flash("Judul minimal 5 karakter.", "error")
        else:
            post = Post(judul=judul, isi=isi, author=current_user)
            db.session.add(post)
            db.session.commit()
            flash("Artikel berhasil ditambahkan.", "success")
            return redirect(url_for("blog.post_detail", post_id=post.id))
    return render_template("form.html", nama_blog=nama_blog, post=None,
                           judul=judul, isi=isi)


@blog_bp.route("/edit/<int:post_id>", methods=["GET", "POST"])
@login_required
def edit_post(post_id):
    post = db.get_or_404(Post, post_id)
    if post.user_id != current_user.id:
        abort(403)

    judul = post.judul
    isi = post.isi
    if request.method == "POST":
        judul = request.form.get("judul", "").strip()
        isi = request.form.get("isi", "").strip()
        if not judul or not isi:
            flash("Judul dan isi wajib diisi.", "error")
        elif len(judul) < 5:
            flash("Judul minimal 5 karakter.", "error")
        else:
            post.judul = judul
            post.isi = isi
            db.session.commit()
            flash("Artikel berhasil diperbarui.", "success")
            return redirect(url_for("blog.post_detail", post_id=post.id))
    return render_template("form.html", nama_blog=nama_blog, post=post,
                           judul=judul, isi=isi)


@blog_bp.route("/hapus/<int:post_id>", methods=["POST"])
@login_required
def hapus_post(post_id):
    post = db.get_or_404(Post, post_id)
    if post.user_id != current_user.id:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash("Artikel berhasil dihapus.", "success")
    return redirect(url_for("blog.posts"))
