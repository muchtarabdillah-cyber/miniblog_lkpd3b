from flask import Blueprint, jsonify, request
from flask_login import current_user
from app.extensions import db
from app.models import Post

api_bp = Blueprint("api", __name__, url_prefix="/api")


def post_to_dict(post):
    return {
        "id": post.id,
        "judul": post.judul,
        "isi": post.isi,
        "penulis": post.author.username,
        "tanggal": post.tanggal.isoformat() if post.tanggal else None,
    }


@api_bp.route("/posts")
def api_posts():
    q = request.args.get("q", "").strip()
    query = Post.query.order_by(Post.tanggal.desc())
    if q:
        query = query.filter(Post.judul.contains(q))
    return jsonify([post_to_dict(post) for post in query.all()])


@api_bp.route("/posts/count")
def api_posts_count():
    return jsonify({"total": Post.query.count()})


@api_bp.route("/posts/<int:post_id>", methods=["GET"])
def api_post_detail(post_id):
    post = db.session.get(Post, post_id)
    if post is None:
        return jsonify({"error": "Artikel tidak ditemukan"}), 404
    return jsonify(post_to_dict(post))


@api_bp.route("/posts", methods=["POST"])
def api_create_post():
    if not current_user.is_authenticated:
        return jsonify({"error": "Login diperlukan"}), 401

    data = request.get_json(silent=True) or {}
    judul = str(data.get("judul", "")).strip()
    isi = str(data.get("isi", "")).strip()
    if not judul or not isi:
        return jsonify({"error": "judul dan isi wajib diisi"}), 400

    post = Post(judul=judul, isi=isi, author=current_user)
    db.session.add(post)
    db.session.commit()
    return jsonify(post_to_dict(post)), 201


@api_bp.route("/posts/<int:post_id>", methods=["DELETE"])
def api_delete_post(post_id):
    if not current_user.is_authenticated:
        return jsonify({"error": "Login diperlukan"}), 401
    post = db.session.get(Post, post_id)
    if post is None:
        return jsonify({"error": "Artikel tidak ditemukan"}), 404
    if post.user_id != current_user.id:
        return jsonify({"error": "Bukan artikel Anda"}), 403
    db.session.delete(post)
    db.session.commit()
    return "", 204
