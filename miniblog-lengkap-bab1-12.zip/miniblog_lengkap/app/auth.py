import re
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, current_user
from app.extensions import db
from app.models import User

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("blog.home"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not re.fullmatch(r"\w+", username):
            flash("Username hanya boleh huruf, angka, dan garis bawah.", "error")
        elif len(username) < 3:
            flash("Username minimal 3 karakter.", "error")
        elif len(password) < 6:
            flash("Kata sandi minimal 6 karakter.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username sudah digunakan.", "error")
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash("Registrasi berhasil. Silakan login.", "success")
            return redirect(url_for("auth.login"))

    return render_template("register.html", nama_blog="Mini Blog")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("blog.home"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()

        if user is not None and user.check_password(password):
            login_user(user)
            flash("Login berhasil.", "success")
            next_url = request.args.get("next", "")
            if next_url.startswith("/") and not next_url.startswith("//"):
                return redirect(next_url)
            return redirect(url_for("blog.posts"))

        flash("Username atau kata sandi salah.", "error")

    return render_template("login.html", nama_blog="Mini Blog")


@auth_bp.route("/logout", methods=["POST"])
def logout():
    logout_user()
    flash("Kamu sudah logout.", "success")
    return redirect(url_for("blog.home"))
