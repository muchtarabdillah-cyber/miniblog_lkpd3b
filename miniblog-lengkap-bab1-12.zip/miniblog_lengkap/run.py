from app import create_app
from app.extensions import db
from app.models import Post

app = create_app()

@app.cli.command("init-db")
def init_db():
    """Siapkan tabel dan tiga artikel contoh untuk latihan."""
    db.create_all()
    if Post.query.count() == 0:
        # Artikel contoh ini dimiliki akun bernama Admin jika akun tersebut ada.
        from app.models import User
        admin = User.query.filter_by(username="admin").first()
        if admin is None:
            admin = User(username="admin")
            admin.set_password("admin12345")
            db.session.add(admin)
            db.session.flush()
        db.session.add_all([
            Post(judul="Belajar Flask", isi="Flask adalah micro-framework Python.", author=admin),
            Post(judul="Belajar Jinja2", isi="Jinja2 adalah mesin template untuk Flask.", author=admin),
            Post(judul="Belajar Routing", isi="Routing menghubungkan URL dengan fungsi Python.", author=admin),
        ])
        db.session.commit()
    print("Database siap digunakan.")
    print("Akun contoh: admin / admin12345")

if __name__ == "__main__":
    app.run(debug=app.config["DEBUG"], port=8080)
