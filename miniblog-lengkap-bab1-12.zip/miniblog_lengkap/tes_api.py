"""Tes sederhana endpoint API. Jalankan server di terminal lain terlebih dahulu."""
import requests

BASE = "http://127.0.0.1:8080"
session = requests.Session()

# Buat akun tes baru atau gunakan akun yang sudah terdaftar.
username = "siswa_api"
password = "rahasia123"
session.post(f"{BASE}/auth/register", data={"username": username, "password": password})
login = session.post(f"{BASE}/auth/login", data={"username": username, "password": password})
print("Login:", login.status_code)

buat = session.post(
    f"{BASE}/api/posts",
    json={"judul": "Artikel dari API", "isi": "Percobaan membuat artikel melalui JSON."},
)
print("POST valid:", buat.status_code, buat.json() if buat.content else "")

invalid = session.post(f"{BASE}/api/posts", json={"judul": "", "isi": ""})
print("POST invalid:", invalid.status_code)

missing = session.get(f"{BASE}/api/posts/999999")
print("GET tidak ditemukan:", missing.status_code, missing.json())

tanpa_login = requests.post(
    f"{BASE}/api/posts",
    json={"judul": "Tanpa login", "isi": "Tidak boleh dibuat."},
)
print("POST tanpa login:", tanpa_login.status_code)
